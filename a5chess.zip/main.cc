#include "controller.h"

int main(int argc, char const *argv[]) {
	Controller c;
	c.play();
	return 0;
}
